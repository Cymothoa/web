import request from '../utils/request';

export function banner() {
  return request.ajaxGet('/banner');
}
