function Chat() {
  return <div className="chat"></div>;
}
export default Chat;
