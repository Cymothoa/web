import { NavBar, Switch, List, Space } from 'antd-mobile';
import { useNavigate } from 'react-router-dom';
import { AddSquareOutline } from 'antd-mobile-icons';
function RoleList() {
  const navigate = useNavigate();
  const right = (
    <div
      onClick={() => {
        navigate('/');
      }}
      style={{ fontSize: 24 }}>
      <Space style={{ '--gap': '16px' }}>
        <AddSquareOutline />
      </Space>
    </div>
  );
  return (
    <div className="item-list">
      <NavBar right={right} onBack={() => navigate(-1)}>
        我创建的角色
      </NavBar>
      <div>
        <List header="复杂列表">
          <List.Item extra={<Switch defaultChecked />}>新消息通知</List.Item>
          <List.Item extra="未开启" clickable>
            大字号模式
          </List.Item>
          <List.Item description="管理已授权的产品和设备" clickable>
            授权管理
          </List.Item>
        </List>
      </div>
    </div>
  );
}

export default RoleList;
